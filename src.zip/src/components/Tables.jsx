import React from 'react'

const Tables = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default Tables