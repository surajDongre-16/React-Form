import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import Tables from './Tables'
import {
    Checkbox,
    FormControl,
    FormLabel,
    Heading,
    Input,
    NumberDecrementStepper,
    NumberIncrementStepper,
    NumberInput,
    NumberInputField,
    NumberInputStepper,
    Select,
    Stack,
  } from '@chakra-ui/react'

  import {
    Table,
    Thead,
    Tr,
    Th,
    TableContainer,
  } from '@chakra-ui/react'
import { PhoneIcon, AddIcon, WarningIcon } from '@chakra-ui/icons'
import { Button, ButtonGroup } from '@chakra-ui/react'
import styles from "./forms.module.css"
import TabelItem from './TabelItem'



const Forms = () => {

    const [newEntery,setNewEntery]=useState({})
    const [userInfo,setUserInfo]=useState([])
    const [page,setPage]=useState(1)
    const [limit,setLimit]=useState(5)
    const [totalCount,setTotalCount]=useState(0)

    const saveInfo=(e)=>{
        e.preventDefault()

        fetch(`http://localhost:8080/forms?_page=${page}&_limit=${limit}`,{
            method : "POST",
            headers:{
                "content-type":"application/json",
            },
            body:JSON.stringify({
                name: newEntery.name,
                age: newEntery.age,
                address: newEntery.address,
                department: newEntery.department,
                salary: newEntery.salary,
                married: newEntery.married,
                profilepic:"https://cdn.pixabay.com/photo/2015/03/04/22/35/head-659652__340.png"
            })
        })
        .then((res)=>res.json())
        .then((data)=>setUserInfo([...userInfo,data]))
        setNewEntery({})
    }

    useEffect(()=>{
        fetch(`http://localhost:8080/forms?_page=${page}&_limit=${limit}`)
        .then((res)=>res.json())
        .then((data)=>{
            setUserInfo(data)
            // console.log(data)
        })
    },[])
       

    const handleChange=(e)=> {
        let {name, checked, type, value, files}= e.target
        if(type==="checkbox"){
            setNewEntery({
                ...newEntery,
                [name]:checked,
            })
        }
        else if(type==="file"){
            setNewEntery({
                ...newEntery,
                [name]:files,
            })
        }
        else{
            setNewEntery({
                ...newEntery,
                [name]:value,
            })
        }
    }

  return (
    <div>
        
        <form onSubmit={saveInfo} className={styles.form}>
            <Heading>React Form</Heading>
            <br />
            <FormControl isRequired>
                <FormLabel htmlFor='first-name'>First name</FormLabel>
                <Input name='name' placeholder='Enter Full Name' onChange={handleChange} />
                <FormLabel htmlFor='first-name'>Age</FormLabel>
                <NumberInput  size='lg' maxW={32} defaultValue={''}>
                <NumberInputField name='age' type="number" onChange={handleChange} />
                    <NumberInputStepper>
                        <NumberIncrementStepper />
                        <NumberDecrementStepper />
                    </NumberInputStepper>
                </NumberInput>
                <FormLabel htmlFor='Address'>Address</FormLabel>
                <Input name='address' type="text" placeholder='Enter Address' onChange={handleChange} />
                <FormLabel htmlFor='first-name'>Department</FormLabel>
                    <Select name='department'  placeholder='Select option' onChange={handleChange}>
                        <option value='UI Designer'>UI</option>
                        <option value='UX Designer'>UX</option>
                        <option value='Full Stack Developer'>Full Stack Developer</option>
                        <option value='Front-End'>Front-End</option>
                        <option value='Back-End'>Back-End</option>

                    </Select>
                <FormLabel htmlFor='first-name'>Salary</FormLabel>
                <NumberInput size='lg' maxW={72} defaultValue={0}>
                    <NumberInputField name='salary' type="number" onChange={handleChange} />
                </NumberInput>
                <FormLabel htmlFor='first-name'>Maritial Status</FormLabel>
                <Stack spacing={[1, 5]} direction={['column', 'row']}>
                    <Checkbox name='married' type="checkbox" size='lg' colorScheme='orange' isChecked={newEntery.checked} onChange={handleChange}>
                        Married
                    </Checkbox>
                </Stack>
                <FormLabel htmlFor='profile-picture'>Profile Picture</FormLabel>
                <Input name="profilepic" type="file" placeholder='select file' onChange={handleChange} />
            </FormControl>
            <br />
            <Button type="submit" colorScheme='purple'>Purple</Button>
        </form>
        
        <Heading>Employee Details</Heading>
        <br />
        <Tables>
            <TableContainer>
                <Table variant='striped' colorScheme='purple'>
                    {/* <TableCaption>Employee Details</TableCaption> */}
                    <Thead>
                        <Tr>
                            <Th>Name</Th>
                            <Th isNumeric>Age</Th>
                            <Th>Address</Th>
                            <Th>Department</Th>
                            <Th isNumeric>Salary</Th>
                            <Th>Marital State</Th>
                            <Th>Profile Photo</Th>
                        </Tr>
                    </Thead>
                    {userInfo.map((list)=>(
                        <TabelItem key={list.id} list={list} />
                    ))}
                </Table>
            </TableContainer>
        </Tables>
    </div>
  )
}

export default Forms